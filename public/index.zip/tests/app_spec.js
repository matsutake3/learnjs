describe('LeanJs', function(){
   it('can show a problem view', function(){
      learnjs.showView('#problem-1');
      except($('.view-container .problem-view').length).toEqual(1);
   });
});
